Kodi Telekom Sport Addon
========================

Über
----

Mit diesem Addon kann man die Sportstreams von [Telekom Sport][1] ansehen.

Installation
------------

Das zipfile von der [Releases Seite][2] downloaden und in Kodi unter Addons
installieren.


About
-----

This addon let's you watch the sports streams from [Telekom Sport][1].

Installation
------------

Download the addon zipfile from the [releases page][2] and install it in
Kodi -> Addons.

[1]: https://www.telekomsport.de
[2]: https://github.com/hubsif/kodi-telekomsport/releases
