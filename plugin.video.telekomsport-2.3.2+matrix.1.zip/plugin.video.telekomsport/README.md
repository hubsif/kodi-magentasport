Kodi Magenta Sport Addon (ehem. Telekom Sport)
==============================================

Über
----

Mit diesem Addon kann man die Sportstreams von [Magenta Sport][1] (ehem.
Telekom Sport) ansehen.

Installation
------------

Das zipfile von der [Releases Seite][2] downloaden und in Kodi unter Addons
installieren.

Bei Problemen gerne ein Github-Issue aufmachen oder eine E-Mail an
hubsif@gmx.de.

About
-----

This addon let's you watch the sports streams from [Magenta Sport][1]
(formerly Telekom Sport).

Installation
------------

Download the addon zipfile from the [releases page][2] and install it in
Kodi -> Addons.

[1]: https://www.magentasport.de
[2]: https://github.com/hubsif/kodi-magentasport/releases
